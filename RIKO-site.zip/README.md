# RIKO

Sistema de finanças da casa: salários, ganhos extra, contas fixas (valor ou percentagem do salário), gastos do mês, metas com percentagem automática da sobra, gráficos, evolução mensal e totais acumulados.

## Como publicar no Vercel
1. Em vercel.com, clique em **Add New → Project**.
2. Escolha o repositório **RIKO** e clique em **Import**.
3. Em *Framework Preset* deixe **Other** e clique em **Deploy**.

O site é um único ficheiro `index.html`, sem instalação nem build.

## Onde ficam os dados
Fora do claude.ai, os dados ficam guardados **no próprio navegador** de quem usa (localStorage).
Cada telemóvel ou computador tem os seus próprios dados, e limpar os dados do navegador apaga-os.
